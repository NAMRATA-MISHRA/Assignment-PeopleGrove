package Assignment.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import Assignment.AbstractComponents.AbstractComponent;

public class inboxPage extends AbstractComponent{

WebDriver driver;
	
	public inboxPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[contains(@class,'rich-text ql-editor')]//p[contains(text(),'hello')]")
	WebElement convo;
	
	@FindBy(xpath="//div[contains(@class,'inboxV2__section-center__top__profile')]//button[contains(@type,'button')]")
	WebElement viewProfile;
	
	public careerPathPage inboxConvo(String message) {
	Assert.assertTrue(convo.equals(message));
	viewProfile.click();
	careerPathPage chooseCareer = new careerPathPage(driver);
    return chooseCareer;
	}
	
}
