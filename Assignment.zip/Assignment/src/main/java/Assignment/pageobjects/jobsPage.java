package Assignment.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Assignment.AbstractComponents.AbstractComponent;

public class jobsPage extends AbstractComponent {

	WebDriver driver;
	public jobsPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
		
	@FindBy(xpath="//body/div[@id='root']/div[contains(@class,'app-container')]/main[@id='main']/div[contains(@class,'jobsV2_jobV2Wrapper__1NZ7q')]/div[contains(@class,'pg-container-v2 jobsV2-container')]/div[contains(@class,'Tabs-module_tabs__0asjm job-category-tabs-wrapper Tabs-module_leftView__WNiiV')]/div[@id='tabpanel-all']/div[contains(@class,'jobs-list-container navigation-v2')]/div[contains(@class,'job-list navigation-v2')]/div/div[3]/div[1]")
	WebElement jobOptionButton;
	
	@FindBy(xpath="//div[contains(@class,'slick-slide slick-active slick-current')]//div//div//div//button[contains(@type,'button')][normalize-space()='Ask a Question']")
	WebElement askAQuesButton;
	
	@FindBy(xpath="//div[contains(@class,'fr-element fr-view')]//p")
	WebElement sendText;
	
	@FindBy(xpath="//div[contains(@class,'slick-slide slick-active slick-current')]//div//div//div//div[contains(@class,'PersonCard_root__2QNEP')]")
	WebElement sendButton;
	
	@FindBy(xpath="//div[@class='slick-slide slick-active slick-current']//div//div//div//button[@type='button'][normalize-space()='Keep the Convo Going!']")
	WebElement KeepConvoGoingbutton;
	
	
	public inboxPage clickJob(String Text) throws InterruptedException {
		jobOptionButton.click();
		Thread.sleep(800);
		((JavascriptExecutor)driver).executeScript("document.querySelector('.job-detail-body').scrollTop=500");
		askAQuesButton.click();
		sendText.sendKeys(Text);
		sendButton.click();
		KeepConvoGoingbutton.click();
		inboxPage inbox = new inboxPage(driver);
		return inbox;
	}
	
	

}
