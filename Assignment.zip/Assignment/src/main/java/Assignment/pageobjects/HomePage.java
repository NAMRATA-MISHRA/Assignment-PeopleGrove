package Assignment.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Assignment.AbstractComponents.AbstractComponent;

public class HomePage extends AbstractComponent{

	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[normalize-space()='Career']")
	WebElement careerButton;
	
	@FindBy(xpath="//p[normalize-space()='Jobs']")
	WebElement jobsButton;
	
	public jobsPage performContextMenuClick() {
	    Actions actions = new Actions(driver);
	    actions.moveToElement(careerButton).contextClick().build().perform();
	    jobsButton.click();
	    jobsPage job = new jobsPage(driver);
	    return job;
	}
	

}
