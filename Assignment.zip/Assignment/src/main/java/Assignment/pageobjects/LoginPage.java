package Assignment.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Assignment.AbstractComponents.AbstractComponent;

public class LoginPage extends AbstractComponent {

	WebDriver driver;
	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[@aria-label='Continue with Email']")
	WebElement ContinueWithEmailButton;
	
	@FindBy(xpath="//button[@class='ant-btn SignInButton_sign_in_btn__2KctY SignInButton_large__u_AmG']")
	WebElement signInButton;
	
	@FindBy(xpath="//input[@id='email']")
	WebElement userEmail;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement Password;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement submitButton;
	
	
	public HomePage loginApplication(String email,String password) throws InterruptedException {
		userEmail.sendKeys(email);
		Password.sendKeys(password);
		submitButton.click();
		Thread.sleep(50000); // Manual time given to verify captcha
		HomePage actionbutton = new HomePage(driver);
		return actionbutton;
	}
	
	public void signinApplication() {
		signInButton.click();
		ContinueWithEmailButton.click();
	}
	
	public void goTo() {
		driver.get("https://basecopy5.staging.pg-test.com/");
	}
	
}
