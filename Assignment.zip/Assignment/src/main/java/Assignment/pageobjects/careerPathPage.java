package Assignment.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Assignment.AbstractComponents.AbstractComponent;

public class careerPathPage extends AbstractComponent {

	WebDriver driver;
	public careerPathPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//button[normalize-space()='Career']")
	WebElement careerButton;
	
	@FindBy(xpath="//p[normalize-space()='Career Paths']")
	WebElement careerPathPage;
	
	@FindBy(css="Card-module_root__OCF9X pg-components-card Card-module_noBorder__dXyFl Card-module_noPadding__DWpm9")
	List<WebElement> optionsOnPage;
	
	public void ToCareerPathPage() {
		 Actions actions = new Actions(driver);
		 actions.moveToElement(careerButton).contextClick().build().perform();
		 careerPathPage.click();
	}
	
	public void scroll() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor)driver;
	    js.executeScript("window.scrollBy(0,1800)");
	    Thread.sleep(3000);
	}
	
	public List<WebElement> selectOptions() {
		List<String> selectedCareerPaths = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            WebElement careerPath = optionsOnPage.get(i);
            selectedCareerPaths.add(careerPath.getText());
            careerPath.click();
        }
        System.out.println("Selected career paths: " + selectedCareerPaths);
        
//        if(!careerStageOption.isSelected()) {
//        	careerStageOption.click();
//        }
        driver.switchTo();
        
        return optionsOnPage;
	}
	
}
