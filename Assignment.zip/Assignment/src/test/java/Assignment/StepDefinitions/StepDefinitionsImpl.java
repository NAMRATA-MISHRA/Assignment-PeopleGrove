package Assignment.StepDefinitions;

import java.io.IOException;

import Assignment.TestComponent.BaseTest;
import Assignment.pageobjects.HomePage;
import Assignment.pageobjects.LoginPage;
import Assignment.pageobjects.careerPathPage;
import Assignment.pageobjects.inboxPage;
import Assignment.pageobjects.jobsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitionsImpl extends BaseTest {

	public LoginPage loginpage;
	public HomePage actionbutton;
	public jobsPage job ;
	public inboxPage inbox;
	public careerPathPage chooseCareer;
	@Given("^I am on home page with username (.+) and password(.+)$")
	public void i_am_on_home_page(String username,String password) throws IOException, InterruptedException {
		loginpage=launchApplication();
		actionbutton=loginpage.loginApplication(username, password);
		
	}

	@When("I navigate to the Jobs page")
	public void i_navigate_to_the_jobs_page() {
		job = actionbutton.performContextMenuClick();
		
	}

	@When("I click on a job")
	public void i_click_on_a_job() throws InterruptedException {
		inbox = job.clickJob("hello");
	}

	@When("I send a message to any recommended user")
	public void i_send_a_message_to_any_recommended_user() {
		chooseCareer=inbox.inboxConvo("hello");
	}

	@When("I navigate to my inbox")
	public void i_navigate_to_my_inbox() {
		chooseCareer.ToCareerPathPage();
	}

	@Then("I should see the message listed under same user’s chat")
	public void i_should_see_the_message_listed_under_same_user_s_chat() throws InterruptedException {
		chooseCareer.scroll();
	}

	@When("I click on the top banner")
	public void i_click_on_the_top_banner() {
	   
	}

}
