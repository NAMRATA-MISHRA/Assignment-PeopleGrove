package Assignment.tests;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import Assignment.TestComponent.BaseTest;
import Assignment.pageobjects.HomePage;
import Assignment.pageobjects.LoginPage;
import Assignment.pageobjects.careerPathPage;
import Assignment.pageobjects.inboxPage;
import Assignment.pageobjects.jobsPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StandAloneTest extends BaseTest{

	@Test
	public void checkCareerPage() throws IOException, InterruptedException {
		LoginPage loginpage=launchApplication();
		loginpage.signinApplication();
		HomePage actionbutton= loginpage.loginApplication("oliviastone2015@gmail.com", "Automation@123");
		jobsPage job  = actionbutton.performContextMenuClick();
		inboxPage inbox = job.clickJob("hello");
		careerPathPage chooseCareer=inbox.inboxConvo("hello");
		chooseCareer.ToCareerPathPage();
		chooseCareer.scroll();		
		driver.close();
		
	
	}

}


