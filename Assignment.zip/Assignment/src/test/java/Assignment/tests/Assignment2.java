package Assignment.tests;

	import java.util.ArrayList;
	import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;

	public class Assignment2 {

	    private WebDriver driver;

	    public Assignment2() {
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
	        driver = new ChromeDriver();
	    
	        driver.get("https://basecopy5.staging.pg-test.com/");

	        // 2. Click on any 3 career paths from “Inspiration from You” section
	        List<WebElement> careerPaths = driver.findElements(By.cssSelector(".careers-row-body.careers-row-multiple a"));
	        List<String> selectedCareerPaths = new ArrayList<>();
	        for (int i = 0; i < 3; i++) {
	            WebElement careerPath = careerPaths.get(i);
	            selectedCareerPaths.add(careerPath.getText());
	            careerPath.click();
	        }
	        Set w = driver.getWindowHandles();
	        Iterator t = w.iterator();
	        Object ch =  t.next();
	        Object pw = t.next();
	    
	        System.out.println("Selected career paths: " + selectedCareerPaths);

	       
	        WebElement careerStageOption3 = driver.findElement(By.xpath("//select[@id='career-stage']//option[@value='3']"));
	        if (!careerStageOption3.isSelected()) {
	            careerStageOption3.click();
	        }

	        
	        driver.navigate().to("https://example.com/home");
	        driver.navigate().refresh();

	        
	        List<String> recentlyViewedCareers = new ArrayList<>();
	        List<WebElement> recentlyViewedCareerElements = driver.findElements(By.xpath("//div[@class='recently-viewed-careers']//a"));
	        for (WebElement recentlyViewedCareerElement : recentlyViewedCareerElements) {
	            recentlyViewedCareers.add(recentlyViewedCareerElement.getText());
	        }
	        Collections.reverse(selectedCareerPaths);
	        System.out.println("Recently viewed careers: " + recentlyViewedCareers);
	        System.out.println("Is the list reversed? " + selectedCareerPaths.equals(recentlyViewedCareers));
	        driver.quit();
	    }

	}
