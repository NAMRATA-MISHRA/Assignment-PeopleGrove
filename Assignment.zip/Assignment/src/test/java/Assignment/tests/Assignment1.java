package Assignment.tests;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assignment1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://basecopy5.staging.pg-test.com/");
		
		//SignIn
		driver.findElement(By.xpath("//button[@class='ant-btn SignInButton_sign_in_btn__2KctY SignInButton_large__u_AmG']")).click();
		driver.findElement(By.xpath("//button[@aria-label='Continue with Email']")).click();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("namratta10@gmail.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Automation@123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		
		Thread.sleep(50000); // Manual time given to verify captcha
		Actions a = new Actions(driver);
		WebElement move = driver.findElement(By.xpath("//button[normalize-space()='Career']"));
		a.moveToElement(move).contextClick().build().perform();
		driver.findElement(By.xpath("//p[normalize-space()='Jobs']")).click();
		driver.findElement(By.xpath("//body/div[@id='root']/div[contains(@class,'app-container')]/main[@id='main']/div[contains(@class,'jobsV2_jobV2Wrapper__1NZ7q')]/div[contains(@class,'pg-container-v2 jobsV2-container')]/div[contains(@class,'Tabs-module_tabs__0asjm job-category-tabs-wrapper Tabs-module_leftView__WNiiV')]/div[@id='tabpanel-all']/div[contains(@class,'jobs-list-container navigation-v2')]/div[contains(@class,'job-list navigation-v2')]/div/div[3]/div[1]")).click();
		driver.findElement(By.xpath("//div[@class='job-detail-view ']"));
		Thread.sleep(800);
		
		((JavascriptExecutor)driver).executeScript("document.querySelector('.job-detail-body').scrollTop=500");
		//driver.findElement(By.xpath("//div[contains(@class,'slick-slide slick-active slick-current')]//div//div//div//button[contains(@type,'button')][normalize-space()='Keep the Convo Going!']")).click();
		driver.findElement(By.xpath("//div[contains(@class,'slick-slide slick-active slick-current')]//div//div//div//button[contains(@type,'button')][normalize-space()='Ask a Question']")).click();
		driver.findElement(By.xpath("//div[contains(@class,'fr-element fr-view')]//p")).sendKeys("Hello xyz");
		driver.findElement(By.xpath("//div[contains(@class,'slick-slide slick-active slick-current')]//div//div//div//div[contains(@class,'PersonCard_root__2QNEP')]")).click();
		driver.findElement(By.xpath("//div[@class='slick-slide slick-active slick-current']//div//div//div//button[@type='button'][normalize-space()='Keep the Convo Going!']")).click();
		WebElement convo = driver.findElement(By.xpath("//div[contains(@class,'rich-text ql-editor')]//p[contains(text(),'hello')]"));
		Assert.assertTrue(convo.equals("hello"));
		driver.findElement(By.xpath("//div[contains(@class,'inboxV2__section-center__top__profile')]//button[contains(@type,'button')]")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Home']")).click();
		driver.close();
		
		
	}

}

